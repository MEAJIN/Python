x=100
y=200
sum=x+y
print(sum)
