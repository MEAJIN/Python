x=(input("이름을 입력하시오:"))
print(x,"씨, 안녕하세요?")
print("파이썬에 오신 것을 환영합니다.")

a=int(input("첫 번째 정수를 입력하시오:"))
s=int(input("두 번째 정수를 입력하시오:"))

sum = a+s

print(a, "과", s, "의 합은", sum, "입니다.")

      


