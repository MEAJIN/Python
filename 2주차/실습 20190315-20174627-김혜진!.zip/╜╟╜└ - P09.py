number1, number2, number3 = eval(input("세 개의 숫자를 콤마(,)로 구분하여 입력하세요: "))

average = (number1+number2+number3) / 3

print(number1, number2, number3, "의 평균은", average, "입니다.")
