x=7
y=6
print(x+y)
x='7'
y='6'
print(x+y)
