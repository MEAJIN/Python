x=100
y=100
sum=x+y
print(x,"과",y,"의 합은",sum,"입니다.")
