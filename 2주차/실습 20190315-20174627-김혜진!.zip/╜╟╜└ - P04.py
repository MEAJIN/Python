import turtle
t=turtle.Turtle()
t.shape("turtle")

radius=100
t.circle(radius)
t.fd(30)
t.circle(radius)
t.fd(30)
t.circle(radius)
