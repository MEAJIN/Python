import turtle
 t = turtle.Pen()
 t.forward(100)
 t.right(90)
 t.forward(100)
 t.right(90)
 t.forward(100)
 t.right(90)
 t.forward(100)
