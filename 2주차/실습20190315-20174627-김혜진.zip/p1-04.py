import turtle
 t=turtle
 t=turtle.Pen()
 t.forward(80)
 t.left(60)
 t.forward(80)
 t.left(60)
 t.forward(80)
 t.left(60)
 t.forward(80)
 t.left(60)
 t.forward(80)
 t.left(60)
 t.forward(80)
