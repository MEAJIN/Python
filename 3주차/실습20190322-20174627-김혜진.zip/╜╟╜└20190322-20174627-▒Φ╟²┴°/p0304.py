americano_price=int(input("아메리카노 가격은 얼마입니까?"))
cafelatte_price=int(input("카페라떼 가격은 얼마입니까?"))
capucino_price=int(input("카푸치노 가격은 얼마입니까?"))

americanos=int(input("아메리카노 판매 개수:"))
cafelattes=int(input("카페라떼 판매 개수:"))
capucinos=int(input("카푸치노 판매 개수:"))

sales=americanos*americano_price
sales=sales+cafelattes*cafelatte_price
sales=sales+capucinos*capucino_price
print("총 매출은",sales,"입니다")
