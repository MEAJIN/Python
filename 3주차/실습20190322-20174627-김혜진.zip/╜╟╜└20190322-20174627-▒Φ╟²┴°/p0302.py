sec=1000
minutes=1000//60
remainder=1000%60
print(minutes,remainder)
