ctemp=int(input("섭씨온도:"))
ftemp=ctemp*9.0/5.0+32.0
print("화씨온도:",ftemp)
