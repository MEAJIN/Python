Python 3.6.6 (v3.6.6:4cf1f54eb7, Jun 27 2018, 03:37:03) [MSC v.1900 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> import time
>>> t_sec = int(time.time())
>>> t_min = int(time.time())
>>> t_hours = int(time.time())
>>> t_sec % 60
41
>>> t_min % 60
12
>>> t_hours % 24
10
>>> t_sec
1553230301
>>> t_sec % 60
41
>>> print("현재시간(영국 그리니치 시간) : ", t_sec%60,"시", t_min%60,"분", t_hours,"초")
현재시간(영국 그리니치 시간) :  41 시 12 분 1553230354 초
>>> print("현재시간(영국 그리니치 시간) : ", t_sec%60,"시", t_min%60,"분", t_hours%24,"초")
현재시간(영국 그리니치 시간) :  41 시 12 분 10 초
>>> print("현재시간(영국 그리니치 시간) : ", t_sec%24,"시", t_min%60,"분", t_hours%60,"초")
현재시간(영국 그리니치 시간) :  5 시 12 분 34 초
>>> print("현재시간(한국시간) : ", t_sec%60+9,"시", t_min%60,"분", t_hours,"초")
현재시간(한국시간) :  50 시 12 분 1553230354 초
>>> print("현재시간(한국시간) : ", (t_sec%24)+9,"시", t_min%60,"분", t_hours%60,"초")
현재시간(한국시간) :  14 시 12 분 34 초
>>> t_sec/60
25887171.683333334
>>> t_min/60
25887172.2
>>> 
