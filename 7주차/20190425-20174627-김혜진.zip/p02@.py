for i in [1,2,3,4,5,6,7,8,9]:
    print("9*",i,"=",9*i)

a=1
while a<9:
     print("9*",a,"=",9*a)
     a = a+1
