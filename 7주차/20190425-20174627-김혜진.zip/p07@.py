

n=int(input("정수를 입력하시오.:"))

fact=1

a=0
while a <1,n+1:
    fact=fact * i
    a=a+1

print(n,"!은", fact, "이다.")

