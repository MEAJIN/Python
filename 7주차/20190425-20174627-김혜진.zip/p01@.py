for a in [1, 2, 3, 4, 5]:
    print(a, "번째 방문을 환영합니다!!!")

i=1
while i<6 :
    print(i, "번째 방문을 환영합니다!!!")
    i = i +1
