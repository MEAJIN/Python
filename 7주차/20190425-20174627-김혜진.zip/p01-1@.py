for letter in 'Python':
    print('Current letter:', letter)

print()

fruits=['banana', 'apple', 'mango']
for fruit in fruits :
    print("Current fruit:", fruit)

print('Using Index')
for index in range(len(fruits)):
    print('Current fruit:', fruits[index])

print()

p = "Python"

count = 0

while count < len(p):

    print('Current letter : ', p[count])

    count += 1

print()

fruits = ['banana','apple','mango']

count = 0

while count < len(fruits):

    print('Current fruit : ', fruits[count])

    count += 1

print('Using Index')

count = 0

while count < len(fruits):

    print('Current fruit : ', fruits[count])

    count += 1
