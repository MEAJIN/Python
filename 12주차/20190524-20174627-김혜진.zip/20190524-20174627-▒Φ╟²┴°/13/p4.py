class car:
    def __init__(self, speed, color, model):
        self.speed = speed
        self.color = color
        self.model = model

    def drive(self):
        self.speed = 60

aCar = car(0, "blue", "E-class")
bCar = car(0, "red", "A5")
cCar = car(0, "white", "A6")



print(aCar)

