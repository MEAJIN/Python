import turtle

t1 = turtle.Turtle()
t2 = turtle.Turtle()

t1.shape("turtle")
t1.forward(100)

t2.left(90)
t2.circle(30)
