import math

class Circle :
    
        def __init__(self,radius=1):
            self.radius = radius

        def getPerimeter(self) :
            return 2 * self.radius * math.pi

        def getArea(self) :
            return self.radius * self.radius * math.pi

        def setRadius(self,radius) :
            self.radius = radius

if __name__=='__main__':
    c=Circle(5)
    print("Radius=",c.radius)
    print("Perimeter=",c.getPerimeter())
    print("Area=",c.getArea())
