items = {}
infile = open("items.txt","r")

for line in infile :
    (item,money,sale,stock) = line.split()
    items[item] = [int(money),int(sale),int(stock)]

def printItem(key) :
    lt = items[key]
    print(key + '\t가격=' + str(lt[0]) + '    \t판매량=' + str(lt[1])  + '\t재고=' + str(lt[2]))

def statusPrint() :
    for item in items.keys() :
        printItem(item)

def printKey() :
    for item in items.keys() :
        printItem(item)   
    
def sellFunc() :
    printKey()
    key = input("판매한 물품은 무엇인가요?")
    if key in items.keys():
        lt = items[key]
        print(key + '\t가격=' + str(lt[0]) + '    \t판매량=' + str(lt[1]) + '\t재고=' + str(lt[2]))

        num = int(input("판매한 수량은 어떻게 되는가?"))

        if num > lt[2] :
                print("판매한 수량이 재고보다 많습니다. 입력이 불가합니다.")
                
        elif num <= lt[2] :
            lt[1] = lt[1] + num
            lt[2] = lt[2] - num
            printItem(key)
         
    else :
        print("판매하지 않는 물품입니다.")

def addFunc() :
    add = open("items.txt","a")
    add.write(input("물품이름:") + " ")
    add.write(input("단가:") + " ")
    add.write(input("판매수량:") + " ")
    add.write(input("재고:") + "\n")
    add.close()

    for line in infile:
        (item,money,sale,stock) = line.split()
        items[item] = [int(money),int(sale),int(stock)]
        
def plusFunc() :
    printKey()
    key = input("입고된 물품은 무엇인가요?")
    if key in items.keys() :
        lt = items[key]
        print(key + '\t가격=' + str(lt[0])
          + '    \t판매량=' + str(lt[1])
          + '\t재고=' + str(lt[2]))

        num = int(input("입고된 수량은 어떻게 되는가?"))
        
        lt[2] = lt[2] + num
        printItem(key)

def saveFunc() :
    save = open("items.txt","w")
    for item in items.keys():
        save.write(item + " " + str(items[item][0]) + " " + str(items[item][1])+ " " + str(items[item][2]) + "\n")
    save.close()

def changeFunc() :
    printKey()
    key = input("단가를 변경할 물품은 무엇인가요?")
    if key in items.keys() :
        lt = items[key]
        print(key + '\t가격=' + str(lt[0])  + '    \t판매량=' + str(lt[1]) + '\t재고=' + str(lt[2]))

        num = int(input("변경된 단가는?"))
        
        lt[0] = num
        printItem(key)

    
while True :
    cmd = input("명령을 입력하세요(출력,판매,추가,입고,저장,변경,중지):")

    if cmd == "출력" :
        statusPrint()
    
    elif cmd == "판매" :
        sellFunc()

    elif cmd == "추가":
        addFunc()

    elif cmd == "입고":
        plusFunc()
    
    elif cmd == "저장":
        saveFunc()

    elif cmd == "변경":
        changeFunc()

    elif cmd == "중지" :
        print("재고관리 프로그램을 중지합니다.")
        break

    else :
        print("적합하지않은 명령입니다.")
